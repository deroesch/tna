package org.deroesch.tna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TnaApplicationTests {

	@Test
	void contextLoads() {
	}

}
